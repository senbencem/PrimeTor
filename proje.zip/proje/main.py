import os
import sys
import threading
import subprocess
import shutil
from functools import partial

# Kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.utils import platform
from kivy.core.window import Window

# ---------------------------------------------------------------------------
# BUILDOZER.SPEC GÜNCELLEMESİ (ÇOK ÖNEMLİ)
# ---------------------------------------------------------------------------
# Bu yapının çalışması için buildozer.spec dosyasında şu kısımları değiştirmelisin:
#
# 1. Klasör ve Uzantılar:
# source.include_exts = py, png, jpg, kv, atlas, so, 
# source.include_patterns = assets/*, tor/*, tor/Kopru/*
#
# 2. İzinler:
# android.permissions = INTERNET, ACCESS_NETWORK_STATE
# ---------------------------------------------------------------------------

class PrimeApp(App):
    def build(self):
        self.tor_process = None
        self.is_connected = False
        
        # --- UI Tasarımı ---
        self.layout = BoxLayout(orientation='vertical', padding=30, spacing=20)
        Window.clearcolor = (0.1, 0.1, 0.12, 1) # Modern Koyu

        self.status_label = Label(
            text="Prime: Tor + Bridge Mode\nDosyalar Hazır",
            font_size='18sp',
            halign='center',
            color=(0.9, 0.9, 0.9, 1),
            size_hint=(1, 0.6)
        )
        self.layout.add_widget(self.status_label)

        self.connect_btn = Button(
            text="SİSTEMİ BAŞLAT",
            font_size='20sp',
            background_normal='',
            background_color=(0.2, 0.6, 0.8, 1),
            size_hint=(1, 0.2),
            on_press=self.start_sequence
        )
        self.layout.add_widget(self.connect_btn)

        self.footer = Label(
            text="Architecture: aarch64\nFolder: /tor & /Kopru",
            font_size='11sp',
            color=(0.5, 0.5, 0.5, 1),
            size_hint=(1, 0.1)
        )
        self.layout.add_widget(self.footer)

        return self.layout

    def start_sequence(self, instance):
        if not self.is_connected:
            self.connect_btn.disabled = True
            self.status_label.text = "Dosya Sistemi Kontrol Ediliyor..."
            
            t = threading.Thread(target=self.manage_filesystem_and_run)
            t.daemon = True
            t.start()

    def get_source_path(self):
        """Proje içindeki 'tor' klasörünün yolunu bulur."""
        # Android'de veya PC'de main.py'nin olduğu dizin
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tor')

    def get_dest_path(self):
        """Android'in çalıştırılabilir güvenli alanı (user_data_dir/tor)."""
        return os.path.join(self.user_data_dir, 'tor')

    def copy_and_chmod(self):
        """
        tor klasörünü ve içindeki Kopru klasörünü
        Android'in güvenli alanına kopyalar ve yetki verir.
        """
        source_dir = self.get_source_path()
        dest_dir = self.get_dest_path()

        self.update_ui_text("Dosyalar kopyalanıyor...")

        try:
            # 1. Ana 'tor' klasörünü oluştur
            if not os.path.exists(dest_dir):
                os.makedirs(dest_dir)

            # 2. Dosyaları Yinelemeli (Recursive) Olarak Kopyala
            # shutil.copytree kullanmıyoruz çünkü hedef varsa hata verir,
            # manuel döngü daha güvenli.
            
            for root, dirs, files in os.walk(source_dir):
                # Hedefteki karşılık gelen klasör yapısını oluştur
                relative_path = os.path.relpath(root, source_dir)
                dest_root = os.path.join(dest_dir, relative_path)
                
                if not os.path.exists(dest_root):
                    os.makedirs(dest_root)

                for file in files:
                    src_file = os.path.join(root, file)
                    dst_file = os.path.join(dest_root, file)

                    # Dosya yoksa veya boyut farklıysa kopyala (Güncelleme mantığı)
                    if not os.path.exists(dst_file) or os.path.getsize(src_file) != os.path.getsize(dst_file):
                        shutil.copy2(src_file, dst_file)
                    
                    # 3. YETKİLENDİRME (CHMOD 755)
                    # Hem libtor.so hem de Kopru içindeki binary'ler için
                    if platform != 'win':
                        os.chmod(dst_file, 0o755)

            return True

        except Exception as e:
            self.update_ui_text(f"Dosya Hatası:\n{str(e)}")
            return False

    def manage_filesystem_and_run(self):
        """Tüm süreci yöneten ana fonksiyon."""
        
        # 1. Dosya Transferi ve İzinler
        if not self.copy_and_chmod():
            Clock.schedule_once(self.reset_button, 3)
            return

        # 2. Binary Yolu
        tor_bin_path = os.path.join(self.get_dest_path(), 'libtor.so')
        
        # Kopru klasörünün yolu (İleride torrc konfigürasyonu için lazım olacak)
        # bridge_path = os.path.join(self.get_dest_path(), 'Kopru')

        # 3. Çalıştırma
        self.update_ui_text("Tor Motoru Başlatılıyor...")
        
        try:
            # LD_LIBRARY_PATH ayarı gerekebilir (so dosyaları için)
            env = os.environ.copy()
            env['LD_LIBRARY_PATH'] = self.get_dest_path() + ':' + env.get('LD_LIBRARY_PATH', '')

            self.tor_process = subprocess.Popen(
                [tor_bin_path],
                # Eğer config dosyası (torrc) kullanacaksan buraya: ['-f', torrc_path] eklersin
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                shell=False,
                cwd=self.get_dest_path() # Çalışma dizinini tor klasörü yap
            )
            
            self.is_connected = True
            Clock.schedule_once(partial(self.update_ui_text, "PRIME AKTİF!\nMotor ve Köprüler Hazır.", (0, 1, 0, 1)), 1)
            Clock.schedule_once(self.change_btn_text, 1)

        except Exception as e:
            self.update_ui_text(f"Çalıştırma Hatası:\n{str(e)}")
            Clock.schedule_once(self.reset_button, 4)

    def update_ui_text(self, text, color=None, dt=None):
        def _update(dt):
            self.status_label.text = text
            if color:
                self.status_label.color = color
        Clock.schedule_once(_update, 0)

    def change_btn_text(self, dt):
        self.connect_btn.text = "ÇALIŞIYOR"
        self.connect_btn.background_color = (0, 0.8, 0, 1)

    def reset_button(self, dt):
        self.connect_btn.disabled = False
        self.connect_btn.text = "TEKRAR DENE"

    def on_stop(self):
        if self.tor_process:
            try:
                self.tor_process.terminate()
            except:
                pass

if __name__ == '__main__':
    PrimeApp().run()